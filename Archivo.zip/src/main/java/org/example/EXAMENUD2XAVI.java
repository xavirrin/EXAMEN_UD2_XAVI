package org.example;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class EXAMENUD2XAVI {
    public void ejercicio1() {

        Scanner teclado = new Scanner(System.in);
        Random aleatorio = new Random();
//NO TE ASUSTES CON TODAS LAS VARIABLES Q TE LO EXPLICO AHORA MISMO
        //AQUI CREO LAS RANDOM A Y B QUE SON LOS DOS NUMEROS QUE GENERARA ALEAOTRIAMENTE EL PC
        int randomA;
        int randomB;
        //ESTA SERA LA VARIABLE EN LA QUE GUARDARE EL NUMERO DE LA ELECCION DEL USUARIO
        int entradausuario;
        //Y AQUI LA ELECCION DEL PC
        int randomPC;
        //AQUI GUARDARE EL RESULTADO Y LE IRE SUMANDO PUNTOS AL QUE GANE
        int contadorusuario = 0;
        int contadorPC = 0;
//ME HAGO BULEANO PARA CREAR BUCLE Y NO SALIR HASTA TERMINAR JUEGO
        boolean y = true;

        while(y){
//ME HAGO UN FOR PARA DETERMINAR LA DURACION DE LA PARTIDA
        for (int i = 1; i <= 5; i++) {
            //ME GENERO LOS DOS RANDOMS + 1 PARA QUE VAYA DE 1 A 50 Y NO DE 0 A 49
            randomA = aleatorio.nextInt(50) + 1;
            randomB = aleatorio.nextInt(50) + 1;
            System.out.println("Ronda " + i);
            System.out.println("¿Cuál crees que es mayor, A o B? (A/B)");
            //TRY CATCH PARA QUE NO SE ROMPA AL INTRODUCIR MAS DE UN AA O BB
            try {
                String entrada = teclado.nextLine();
                //SI LA ENTRADA ES A, a, B, o b, SEGUIMOS, SINO SE  VOLVEMOS A EMPEZAR
                if (entrada.contains("A") || entrada.contains("a") || entrada.contains("B") || entrada.contains("b")) {
                    //CREO SWITCH CASE PARA QUE SI LA ELECCION ES A LA OPCION DEL USUARIO VALGA
                    //LO QUE EL RANDOMA QUE GENERO EL PC Y LE DOY EL B AL PC, Y VICEVERSA
                    switch (entrada) {
                        case "A", "a":
                            entradausuario = randomA;
                            randomPC = randomB;
                            break;
                        case "B", "b":
                            entradausuario = randomB;
                            randomPC = randomA;
                            break;
                        default:
                            throw new IllegalStateException("Unexpected value: " + entrada);
                    }
                    //UNA VEZ DEFINIDOS A Y B, COMIENZA EL JUEGO;
                    //SI MI NUMERO ES MENOR QUE EL DEL PC, PUNTO PARA PC
                    if (entradausuario < randomPC) {
                        contadorPC++;
                        System.out.println("Los números eran: A = " + randomA + " y B = " + randomB);
                        System.out.println("¡Has perdido!");
                        System.out.println("Marcador actual (PC-usuario): " + contadorPC + " - " + contadorusuario);
                        //SI MI NUMERO ES MAYOR, PUNTO PARA MI
                    } else if (entradausuario > randomPC) {
                        contadorusuario++;
                        System.out.println("Los números eran: A = " + randomA + " y B = " + randomB);
                        System.out.println("¡Has ganado!");
                        System.out.println("Marcador actual (PC-usuario): " + contadorPC + " - " + contadorusuario);
                        //SI HAY EMPATE, LE RESTO 1 AL CONTADOR DE RONDAS (i) PARA QUE NO SIGAN CONTANDO
                    } else {
                        i--;
                        System.out.println("Los números eran: A = " + randomA + " y B = " + randomB);
                        System.out.println("¡Empate!");
                        System.out.println("Marcador actual (PC-usuario): " + contadorPC + " - " + contadorusuario);
                    }
                    //UNA VEZ TERMINADO EL JUEGO, EL QUE LLEGUE A 3 PUNTOS HA GANADO
                    if (contadorusuario == 3) {
                        System.out.println("Se acabó el juego. Ganaste!");
                        y = false;
                        break;
                    } else if (contadorPC == 3) {
                        System.out.println("Se acabó el juego. Has perdido...");
                        y = false;
                        break;
                    }
                } else {
                    System.out.println("Debe introducir A, a, B o b.");
                    i--;
                }
            } catch (IllegalStateException e) {
                System.out.println("ERROR, no puedes introducir más de un dígito.");
                teclado.nextLine();
            }
        }
        }
    }

    public void ejercicio2() {
        Scanner teclado = new Scanner(System.in);
        //ME HAGO UNA VARIABLE CON EL AÑO ACTUAL
        int anyoactual = 2024;
        //OTRA CON EL MONTO QUE UTILIZAREMOS MAS ADELANTE
        int monto = 2000;
        //BOOLEANO PARA CREAR UN BUCLE EN EL QUE OBLIGATORIAMENTE TENGAMOS QUE PONER UNA EDAD
        // COMPRENDIDA ENTRE 1 Y 65
        boolean x = true;
        while (x) {
            System.out.println("Introduzca su edad.");
            //TRY CATCH PARA QUE NO SE ME CUELEN LETRAS EN LA EDAD
            try {
                int edad = teclado.nextInt();
                //AQUI CONTROLO QUE LA EDAD SEA MAXIMO 65 AÑOS
                if (edad > 65) {
                    System.out.println("Usted ya está jubilado señor!!");
                }else if (edad > 0) {
                    //AQUI CREO VARIABLE ANYOS SUMANDOLE 65 AL AÑO ACTUAL MAS LA EDAD INTRODUCIDA
                    //PARA SABER DONDE ACABAR EL FOR
                    int anyos = anyoactual + 65 - edad;
                    //INICIO EL FOR EN EL AÑO ACTUAL Y LO ACABO EN EL QUE CUMPLA 65 AÑOS Y LE SUMO UNNO CADA AÑO
                    for (int i = anyoactual; i <= anyos; i++) {
                        System.out.println("Año " + i + ". Monto acumulado: " + monto + ".");
                        //CADA VEZ LE SUMO 2000 AL MONTO QUE INICIE AL PRINCIPIO
                        monto += 2000;
                    }
                    //Y CUANDO LLEGAMOS AL CAMINO CORRECTO CERRAMOS BULEANO
                    x = false;
                } else if (edad > 65) {
                    System.out.println("Usted ya está jubilado señor!!");
                }else if ( edad <= 0) {
                    System.out.println("Usted todavía no ha nacido y ya se quiere jubilar...");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error, introduzca números.");
                teclado.nextLine();
            }
        }
    }
}
