package org.example;

public class Main {
    public static void main(String[] args){

        EXAMENUD2XAVI ejercicio1 = new EXAMENUD2XAVI();
        ejercicio1.ejercicio1();

//        EXAMENUD2XAVI ejercicio2 = new EXAMENUD2XAVI();
//        ejercicio2.ejercicio2();
    }
}